from src.metrics import MetricsCalculator

print("TicketSense-XL")
print("Hybrid NLP and Multi-Classifier Framework")
print("Project environment loaded successfully.")
print("Add your dataset and training pipeline to run model training.")
