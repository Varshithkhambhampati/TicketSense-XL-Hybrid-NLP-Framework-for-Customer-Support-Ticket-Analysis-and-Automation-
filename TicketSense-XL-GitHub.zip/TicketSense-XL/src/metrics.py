import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report, roc_curve, auc
from sklearn.preprocessing import label_binarize

class MetricsCalculator:
    def __init__(self, labels, text_widget=None, results_dir="results"):
        self.labels = list(labels)
        self.text = text_widget
        self.results_dir = results_dir
        os.makedirs(self.results_dir, exist_ok=True)
        self.metrics_df = pd.DataFrame(columns=["Algorithm","Accuracy","Precision","Recall","F1-Score"])
        self.class_report_df = pd.DataFrame()
        self.class_performance_dfs = {}

    def _print(self, message):
        if self.text is not None:
            self.text.insert("end", message)
            self.text.see("end")
        else:
            print(message, end="")

    def calculate_metrics(self, algorithm, predict, y_test, y_score=None):
        y_test, predict = np.asarray(y_test), np.asarray(predict)
        accuracy = accuracy_score(y_test, predict) * 100
        precision = precision_score(y_test, predict, average="macro", zero_division=0) * 100
        recall = recall_score(y_test, predict, average="macro", zero_division=0) * 100
        f1 = f1_score(y_test, predict, average="macro", zero_division=0) * 100

        self.metrics_df = pd.concat([self.metrics_df, pd.DataFrame([{
            "Algorithm": algorithm, "Accuracy": accuracy, "Precision": precision,
            "Recall": recall, "F1-Score": f1
        }])], ignore_index=True)

        self._print(f"\n{algorithm}\nAccuracy: {accuracy:.4f}%\nPrecision: {precision:.4f}%\nRecall: {recall:.4f}%\nF1-Score: {f1:.4f}%\n\n")

        report = classification_report(
            y_test, predict, labels=self.labels,
            target_names=[str(x) for x in self.labels],
            output_dict=True, zero_division=0
        )
        self._print(classification_report(
            y_test, predict, labels=self.labels,
            target_names=[str(x) for x in self.labels], zero_division=0
        ) + "\n")

        report_df = pd.DataFrame(report).transpose()
        report_df["Algorithm"] = algorithm
        self.class_report_df = pd.concat([self.class_report_df, report_df])

        for category in self.labels:
            name = str(category)
            if name not in report:
                continue
            entry = pd.DataFrame([{
                "Algorithm": algorithm,
                "Precision": report[name]["precision"] * 100,
                "Recall": report[name]["recall"] * 100,
                "F1-Score": report[name]["f1-score"] * 100,
                "Support": report[name]["support"]
            }])
            if name not in self.class_performance_dfs:
                self.class_performance_dfs[name] = pd.DataFrame()
            self.class_performance_dfs[name] = pd.concat(
                [self.class_performance_dfs[name], entry], ignore_index=True
            )

        cm = confusion_matrix(y_test, predict, labels=self.labels)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, xticklabels=self.labels, yticklabels=self.labels,
                    annot=True, fmt="g", cmap="viridis", cbar=False)
        plt.title(f"{algorithm} Confusion Matrix")
        plt.xlabel("Predicted Class")
        plt.ylabel("True Class")
        plt.tight_layout()
        safe = algorithm.replace(" ", "_").replace("/", "_")
        plt.savefig(os.path.join(self.results_dir, f"{safe}_confusion_matrix.png"),
                    dpi=300, bbox_inches="tight")
        plt.close()

        if y_score is not None:
            self.plot_roc_curve(algorithm, y_test, y_score)

    def plot_roc_curve(self, algorithm, y_test, y_score):
        y_test, y_score = np.asarray(y_test), np.asarray(y_score)
        mapping = {c: i for i, c in enumerate(self.labels)}
        try:
            y_num = np.array([mapping.get(v, int(v) if str(v).isdigit() else 0) for v in y_test])
        except Exception:
            return
        y_bin = label_binarize(y_num, classes=np.arange(len(self.labels)))
        if y_bin.shape[1] < 2:
            return
        plt.figure(figsize=(10, 8))
        for i in range(y_bin.shape[1]):
            try:
                fpr, tpr, _ = roc_curve(y_bin[:, i], y_score[:, i])
                plt.plot(fpr, tpr, linewidth=2, label=f"{self.labels[i]} (AUC = {auc(fpr,tpr):.2f})")
            except ValueError:
                pass
        try:
            fpr, tpr, _ = roc_curve(y_bin.ravel(), y_score.ravel())
            plt.plot(fpr, tpr, "--", linewidth=3, label=f"Micro-average (AUC = {auc(fpr,tpr):.2f})")
        except ValueError:
            pass
        plt.plot([0, 1], [0, 1], "k--", label="Random Guess")
        plt.title(f"{algorithm} ROC Curves (One-vs-Rest)")
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        plt.legend(loc="lower right")
        plt.grid(True)
        plt.tight_layout()
        safe = algorithm.replace(" ", "_").replace("/", "_")
        plt.savefig(os.path.join(self.results_dir, f"{safe}_roc_curve.png"),
                    dpi=300, bbox_inches="tight")
        plt.close()

    def plot_classification_graphs(self):
        if self.metrics_df.empty:
            return self.metrics_df
        melted = pd.melt(self.metrics_df, id_vars=["Algorithm"],
                         value_vars=["Accuracy","Precision","Recall","F1-Score"],
                         var_name="Parameters", value_name="Value")
        plt.figure(figsize=(12, 6))
        ax = sns.barplot(x="Parameters", y="Value", hue="Algorithm", data=melted)
        plt.title("Classifier Performance Comparison")
        plt.ylabel("Score (%)")
        plt.xlabel("Metrics")
        plt.legend(title="Algorithms", bbox_to_anchor=(1.05, 1), loc="upper left")
        for container in ax.containers:
            ax.bar_label(container, fmt="%.1f", padding=3)
        plt.tight_layout()
        plt.savefig(os.path.join(self.results_dir, "classifier_performance.png"),
                    dpi=300, bbox_inches="tight")
        plt.close()
        return self.metrics_df.round(3)
