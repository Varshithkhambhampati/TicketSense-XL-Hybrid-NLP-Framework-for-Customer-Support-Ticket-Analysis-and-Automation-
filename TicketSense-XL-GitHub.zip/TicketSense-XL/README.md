# TicketSense-XL

TicketSense-XL is a hybrid NLP and machine learning framework for automated customer support ticket analysis. It combines TF-IDF and XLNet-based feature extraction with multiple classifiers to predict ticket outcomes, evaluate model performance, and support faster, scalable decision automation.

## Technologies
Python, NLP, TF-IDF, XLNet, Pandas, NumPy, Scikit-learn, Matplotlib, Seaborn, Tkinter

## Models
- LDA
- QDA
- Histogram Gradient Boosting
- SGD Classifier
- Nearest Centroid

## Workflow
Dataset -> Preprocessing -> EDA -> TF-IDF / XLNet -> Model Training -> Evaluation -> Prediction

## Run in VS Code
```bash
pip install -r requirements.txt
python main.py
```

## Results
The `results` folder stores generated evaluation graphs such as confusion matrices, ROC curves, and classifier performance comparisons.
